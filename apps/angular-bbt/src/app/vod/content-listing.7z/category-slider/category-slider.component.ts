import {
  Component,
  EventEmitter,
  Input,
  Output,
  OnInit,
  OnDestroy,
  ViewChildren,
  ElementRef,
  QueryList,
  ViewChild,
  ChangeDetectorRef
} from '@angular/core';
import { Video, BaseFolder, Presentation, Folder } from '../../content-model';
import { MenuItemCollection } from '../../content-model/menu-item-collection';
import { PanningContainerComponent } from '../../panning/panning-container.component';
import { Subscription, Unsubscribable, of } from 'rxjs';
import { I18nService } from '../../i18n/i18n.service';

@Component({
  selector: 'bbt-category-slider',
  templateUrl: './category-slider.component.html',
  styleUrls: ['./category-slider.component.scss']
})
export class CategorySliderComponent {
  @ViewChildren('linkElement') linkElements!: QueryList<ElementRef>;
  @Input() rowIndex: number;
  @Input() currentRowIndex: number;
  @Input() isFocused: boolean = false;  // Check if this row is focused
  @Input() category: MenuItemCollection & { shouldScroll?: boolean };
  @Output() contentFocused = new EventEmitter<Video | Presentation | Folder>();
  @Output() contentActivated = new EventEmitter<
    Video | Presentation | Folder
  >();
  currentColumnIndex: number = 0;
  currentCategoryId : number = 0;
  locale$ = this.i18nService.currentLocale$;

  constructor(private i18nService: I18nService , private cdr: ChangeDetectorRef) {
    document.body.style.overflow = 'hidden';
    //debugger;
   }
    

    ngAfterViewInit() {
      // Set initial focus on the first a tag
    // this.focusFirstItem();
      
    }
    focusFirstItem(): void {
      this.currentColumnIndex = 0; // Ensure it's the first column
      this.focusOnElement(this.currentColumnIndex); // Focus the first element
      this.updateCurrentCategoryId(); // Update any category logic if needed
    }

  focusNext(): void {
     if (this.currentColumnIndex < this.category.menuItems.length - 1) {
    this.currentColumnIndex++;
  } else {
    this.currentColumnIndex = 0; // Wrap around to first item if at the end
  }
  this.focusOnElement(this.currentColumnIndex);
  this.updateCurrentCategoryId();
  }

  focusPrevious(): void {
    if (this.currentColumnIndex > 0) {
      this.currentColumnIndex--;
    } else {
      this.currentColumnIndex = this.category.menuItems.length - 1; // Wrap to last item if at the start
    }
    this.focusOnElement(this.currentColumnIndex);
    this.updateCurrentCategoryId();
  }

  
   // Scroll to the current item
   scrollToCurrentItem(): void {
    const container = document.querySelector('.horizontal-slider-container');
    const targetItem = container?.children[this.currentColumnIndex];
   //debugger;
    if (targetItem && container) {
      // Scroll to the target item horizontally
      targetItem.scrollIntoView({ behavior: 'smooth', inline: 'nearest' });
    }
  }
  focusOnElement(index: number) {   
    this.cdr.detectChanges();
    const elementsArray = this.linkElements.toArray();
    if (elementsArray[index]) {
      elementsArray[index].nativeElement.focus();
    } else {
      console.log("No element found at index", index);
    }
  }
  updateCurrentCategoryId(): void {
    const currentMenuItem = this.category.menuItems[this.currentColumnIndex]; 
    
    // Check if id or itemId is present and set the currentCategoryId accordingly
    if (currentMenuItem) {
      console.log("currentMenuItem",currentMenuItem);
      this.currentCategoryId = currentMenuItem["id"] || currentMenuItem["itemId"];
      this.selectAndSetFocused(currentMenuItem);
    } else {
      this.currentCategoryId = null; // Handle case when no valid item is found
    }
  }
  selectAndSetFocused(item: Video | BaseFolder | Presentation) {
    this.contentFocused.emit(item as Video | Presentation | Folder);
  }

  selectFocusAndPan(
    item: Video | BaseFolder | Presentation,
    panner: PanningContainerComponent,
    index: number
  ) {
    this.selectAndSetFocused(item);
    panner.shiftToIndex(index);
    this.contentActivated.emit(item as Video | Presentation);
  }
}
